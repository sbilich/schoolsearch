public class InvalidStudentException extends Exception
{
  public InvalidStudentException(String message)
  {
    super(message);
  }
}
